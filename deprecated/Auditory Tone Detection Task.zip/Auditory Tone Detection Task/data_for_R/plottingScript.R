#functions ----
load.packages <- function(pkg) {
  new.pkg <- pkg[!(pkg %in% installed.packages()[, "Package"])]
  if (length(new.pkg)) {
    install.packages(new.pkg, dependencies = T)
  }
  sapply(pkg, require, character.only = T)
}

#packages ----
packages <- c("nlme", "stringr", "dplyr", "ggplot2", "ggpubr", "Hmisc", "plyr", "Rmisc", "retimes", "data.table", "tidyr", "lme4","multcomp", 
              "pastecs", "effects", "DataCombine", "gridExtra", "leaps", "ppcor", "ggm", "readxl", "stringr", "emmeans", "eeptools", "psych","weights",
              "here")

load.packages(packages)

#Plotting conditions

#Quiet
Quiet <- read.csv("Quiet.csv", header = TRUE)
Quiet <- Quiet[-c(1),] #remove first row
Quiet$trials.response <- as.factor(Quiet$trials.response)

QuietPlot <- ggplot(Quiet, aes(x= trials.thisN, y = trials.intensity, color = trials.response)) +
  geom_point(size = 3) + 
  labs(x = "Trial", 
       y = "Intensity in PsychoPy units", 
       title = "Quiet Condition",
       subtitle = paste('Threshold: ', mean(rev(Quiet$trials.intensity)[(1:5)])))+
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.background = element_blank(), 
        axis.line = element_line(colour = "black"),
        legend.position = "none") + 
        scale_color_manual(values=c("red", "blue")) + 
        geom_hline(yintercept=mean(rev(Quiet$trials.intensity)[(1:5)]), linetype="dashed", color = "black") 

#Simultaneous
Simultaneous <- read.csv("Simultaneous.csv", header = TRUE)
Simultaneous <- Simultaneous[-c(1),] #remove first row
Simultaneous$trials.response <- as.factor(Simultaneous$trials.response)

SimultaneousPlot <- ggplot(Simultaneous, aes(x= trials.thisN, y = trials.intensity, color = trials.response)) +
  geom_point(size = 3) + 
  labs(x = "Trial", 
       y = "Intensity in PsychoPy units", 
       title = "Simultaneous Condition",
       subtitle = paste('Threshold: ', mean(rev(Simultaneous$trials.intensity)[(1:5)])))+
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.background = element_blank(), 
        axis.line = element_line(colour = "black"),
        legend.position = "none") + 
  scale_color_manual(values=c("red", "blue")) + 
  geom_hline(yintercept=mean(rev(Simultaneous$trials.intensity)[(1:5)]), linetype="dashed", color = "black") 

#Backward
Backward <- read.csv("Backward.csv", header = TRUE)
Backward <- Backward[-c(1),] #remove first row
Backward$trials.response <- as.factor(Backward$trials.response)

BackwardPlot <- ggplot(Backward, aes(x= trials.thisN, y = trials.intensity, color = trials.response)) +
  geom_point(size = 3) + 
  labs(x = "Trial", 
       y = "Intensity in PsychoPy units", 
       title = "Backward Condition",
       subtitle = paste('Threshold: ', mean(rev(Backward$trials.intensity)[(1:5)])))+
  theme(panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        panel.background = element_blank(), 
        axis.line = element_line(colour = "black"),
        legend.position = "none") + 
  scale_color_manual(values=c("red", "blue")) + 
  geom_hline(yintercept=mean(rev(Backward$trials.intensity)[(1:5)]), linetype="dashed", color = "black") 

ggarrange(QuietPlot, SimultaneousPlot, BackwardPlot, nrow = 1, ncol = 3I)

