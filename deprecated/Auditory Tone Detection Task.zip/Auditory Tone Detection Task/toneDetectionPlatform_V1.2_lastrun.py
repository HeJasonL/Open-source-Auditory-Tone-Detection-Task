﻿#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
This experiment was created using PsychoPy3 Experiment Builder (v2020.1.3),
    on June 25, 2020, at 11:03
If you publish work using this script the most relevant publication is:

    Peirce J, Gray JR, Simpson S, MacAskill M, Höchenberger R, Sogo H, Kastman E, Lindeløv JK. (2019) 
        PsychoPy2: Experiments in behavior made easy Behav Res 51: 195. 
        https://doi.org/10.3758/s13428-018-01193-y

"""

from __future__ import absolute_import, division

from psychopy import locale_setup
from psychopy import prefs
from psychopy import sound, gui, visual, core, data, event, logging, clock
from psychopy.constants import (NOT_STARTED, STARTED, PLAYING, PAUSED,
                                STOPPED, FINISHED, PRESSED, RELEASED, FOREVER)

import numpy as np  # whole numpy lib is available, prepend 'np.'
from numpy import (sin, cos, tan, log, log10, pi, average,
                   sqrt, std, deg2rad, rad2deg, linspace, asarray)
from numpy.random import random, randint, normal, shuffle
import os  # handy system and path functions
import sys  # to get file system encoding

from psychopy.hardware import keyboard



# Ensure that relative paths start from the same directory as this script
_thisDir = os.path.dirname(os.path.abspath(__file__))
os.chdir(_thisDir)

# Store info about the experiment session
psychopyVersion = '2020.1.3'
expName = 'toneDetectionPlatform_V1.2'  # from the Builder filename that created this script
expInfo = {'participant': '', 'Session': '1', 'Tone Length': ['Long', 'Short'], 'Condition': ['Quiet', 'Simultaneous', 'Backward']}
dlg = gui.DlgFromDict(dictionary=expInfo, sortKeys=False, title=expName)
if dlg.OK == False:
    core.quit()  # user pressed cancel
expInfo['date'] = data.getDateStr()  # add a simple timestamp
expInfo['expName'] = expName
expInfo['psychopyVersion'] = psychopyVersion

# Data file name stem = absolute path + name; later add .psyexp, .csv, .log, etc
filename = _thisDir + os.sep + u'data/%s_%s_%s' % (expInfo['participant'], expName, expInfo['date'])

# An ExperimentHandler isn't essential but helps with data saving
thisExp = data.ExperimentHandler(name=expName, version='',
    extraInfo=expInfo, runtimeInfo=None,
    originPath='\\\\kclad.ds.kcl.ac.uk\\anywhere\\UserData\\PSStore01\\k2032175\\My Documents\\Github\\Open-source Auditory Tone Detection (OSATD) Task\\Open-source Auditory Tone Detection (OSATD) Task\\Auditory Tone Detection Task\\toneDetectionPlatform_V1.2_lastrun.py',
    savePickle=True, saveWideText=True,
    dataFileName=filename)
# save a log file for detail verbose info
logFile = logging.LogFile(filename+'.log', level=logging.EXP)
logging.console.setLevel(logging.WARNING)  # this outputs to the screen, not a file

endExpNow = False  # flag for 'escape' or other condition => quit the exp
frameTolerance = 0.001  # how close to onset before 'same' frame

# Start Code - component code to be run before the window creation

# Setup the Window
win = visual.Window(
    size=[1000, 1000], fullscr=False, screen=0, 
    winType='pyglet', allowGUI=True, allowStencil=False,
    monitor='testMonitor', color=[0,0,0], colorSpace='rgb',
    blendMode='avg', useFBO=True, 
    units='height')
# store frame rate of monitor if we can measure it
expInfo['frameRate'] = win.getActualFrameRate()
if expInfo['frameRate'] != None:
    frameDur = 1.0 / round(expInfo['frameRate'])
else:
    frameDur = 1.0 / 60.0  # could not measure, so guess

# create a default keyboard (e.g. to check for escape)
defaultKeyboard = keyboard.Keyboard()

# Initialize components for Routine "setUp"
setUpClock = core.Clock()
#Preset Tone Durations 
if expInfo['Tone Length'] == 'Long':
    presetToneDuration = 0.2 #200ms
if expInfo['Tone Length'] == 'Short':
        presetToneDuration = 0.02 #20ms

#Changes made based on condition 
if expInfo['Condition'] == 'Quiet': #if the Condition is Quiet, turn off background noise 
    noiseVolume = 0
else:
    noiseVolume = 1
if expInfo['Condition'] == 'Simultaneous': #if Condition is 'Simultaneous', make onset 200ms into the trial 
    toneOnset = 0.22 #.22 rather than .20 to account account for the 20ms gap that exists before the noise (starting at 20ms into the trial) at the start of the trial
elif expInfo['Condition'] == 'Backward':  #else if Condition is 'Backward' : make Onset start at 0 (20ms before noise) 
    toneOnset = 0 
else: #else, just start the tone in sync with the start of the noise (as per the 'Quiet' Condition)
    toneOnset = 0.02 
    

# Initialize components for Routine "ITI"
ITIClock = core.Clock()
text = visual.TextStim(win=win, name='text',
    text='ITI',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);
trialNumber = 0



# Initialize components for Routine "firstChoiceSpace"
firstChoiceSpaceClock = core.Clock()
firstVisualStimulus = visual.TextStim(win=win, name='firstVisualStimulus',
    text='1',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
firstChoiceNoise = sound.Sound('Noise_BP_600_1400.wav', secs=0.32, stereo=True, hamming=True,
    name='firstChoiceNoise')
firstChoiceNoise.setVolume(1.0)
firstChoiceProbeTone = sound.Sound('1000', secs=-1, stereo=True, hamming=True,
    name='firstChoiceProbeTone')
firstChoiceProbeTone.setVolume(1.0)

# Initialize components for Routine "ISI"
ISIClock = core.Clock()
ISIVisualStimulus = visual.TextStim(win=win, name='ISIVisualStimulus',
    text='ISI',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=0.0);

# Initialize components for Routine "secondChoiceSpace"
secondChoiceSpaceClock = core.Clock()
secondVisualStimulus = visual.TextStim(win=win, name='secondVisualStimulus',
    text='2',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
secondChoiceNoise = sound.Sound('Noise_BP_600_1400.wav', secs=0.32, stereo=True, hamming=True,
    name='secondChoiceNoise')
secondChoiceNoise.setVolume(1.0)
secondChoiceTone = sound.Sound('1000', secs=-1, stereo=True, hamming=True,
    name='secondChoiceTone')
secondChoiceTone.setVolume(1.0)

# Initialize components for Routine "decisionSpace"
decisionSpaceClock = core.Clock()
decisionTextProbe = visual.TextStim(win=win, name='decisionTextProbe',
    text='In which interval did you hear the tone (1 or 2)?',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);
decisionKey = keyboard.Keyboard()

# Initialize components for Routine "feedbackSpace"
feedbackSpaceClock = core.Clock()
feedback = "defaultFeedback"
feedbackText = visual.TextStim(win=win, name='feedbackText',
    text='default text',
    font='Arial',
    pos=(0, 0), height=0.1, wrapWidth=None, ori=0, 
    color='white', colorSpace='rgb', opacity=1, 
    languageStyle='LTR',
    depth=-1.0);

# Create some handy timers
globalClock = core.Clock()  # to track the time since experiment started
routineTimer = core.CountdownTimer()  # to track time remaining of each (non-slip) routine 

# ------Prepare to start Routine "setUp"-------
continueRoutine = True
# update component parameters for each repeat
# keep track of which components have finished
setUpComponents = []
for thisComponent in setUpComponents:
    thisComponent.tStart = None
    thisComponent.tStop = None
    thisComponent.tStartRefresh = None
    thisComponent.tStopRefresh = None
    if hasattr(thisComponent, 'status'):
        thisComponent.status = NOT_STARTED
# reset timers
t = 0
_timeToFirstFrame = win.getFutureFlipTime(clock="now")
setUpClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
frameN = -1

# -------Run Routine "setUp"-------
while continueRoutine:
    # get current time
    t = setUpClock.getTime()
    tThisFlip = win.getFutureFlipTime(clock=setUpClock)
    tThisFlipGlobal = win.getFutureFlipTime(clock=None)
    frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
    # update/draw components on each frame
    
    # check for quit (typically the Esc key)
    if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
        core.quit()
    
    # check if all components have finished
    if not continueRoutine:  # a component has requested a forced-end of Routine
        break
    continueRoutine = False  # will revert to True if at least one component still running
    for thisComponent in setUpComponents:
        if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
            continueRoutine = True
            break  # at least one component has not yet finished
    
    # refresh the screen
    if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
        win.flip()

# -------Ending Routine "setUp"-------
for thisComponent in setUpComponents:
    if hasattr(thisComponent, "setAutoDraw"):
        thisComponent.setAutoDraw(False)
# the Routine "setUp" was not non-slip safe, so reset the non-slip timer
routineTimer.reset()

# set up handler to look after randomisation of trials etc
conditions = data.importConditions('..\\questConditionsFile.xlsx')
trials = data.MultiStairHandler(stairType='quest', name='trials',
    nTrials=50,
    conditions=conditions,
    method='random',
    originPath=-1)
thisExp.addLoop(trials)  # add the loop to the experiment
# initialise values for first condition
level = trials._nextIntensity  # initialise some vals
condition = trials.currentStaircase.condition

for level, condition in trials:
    currentLoop = trials
    # abbreviate parameter names if possible (e.g. rgb=condition.rgb)
    for paramName in condition:
        exec(paramName + '= condition[paramName]')
    
    # ------Prepare to start Routine "ITI"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    if trialNumber == 0:
        halfNTrials = int(trials.nTrials/2)
        trialList = ['1']*halfNTrials + ['2']*halfNTrials
        np.random.shuffle(trialList)
        print(trialList)
    
    toneVolume = level
    # keep track of which components have finished
    ITIComponents = [text]
    for thisComponent in ITIComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ITIClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ITI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ITIClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ITIClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *text* updates
        if text.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            text.frameNStart = frameN  # exact frame index
            text.tStart = t  # local t and not account for scr refresh
            text.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(text, 'tStartRefresh')  # time at next scr refresh
            text.setAutoDraw(True)
        if text.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > text.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                text.tStop = t  # not accounting for scr refresh
                text.frameNStop = frameN  # exact frame index
                win.timeOnFlip(text, 'tStopRefresh')  # time at next scr refresh
                text.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ITIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ITI"-------
    for thisComponent in ITIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addOtherData('text.started', text.tStartRefresh)
    trials.addOtherData('text.stopped', text.tStopRefresh)
    
    # ------Prepare to start Routine "firstChoiceSpace"-------
    continueRoutine = True
    # update component parameters for each repeat
    condition = trialList[trialNumber]
    if condition == '1':
        toneDuration = presetToneDuration
    
    elif condition == '2':
        toneDuration = 0
    firstChoiceNoise.setSound('Noise_BP_600_1400.wav', secs=0.32, hamming=True)
    firstChoiceNoise.setVolume(noiseVolume, log=False)
    firstChoiceProbeTone.setSound('1000', secs=toneDuration, hamming=True)
    firstChoiceProbeTone.setVolume(toneVolume, log=False)
    # keep track of which components have finished
    firstChoiceSpaceComponents = [firstVisualStimulus, firstChoiceNoise, firstChoiceProbeTone]
    for thisComponent in firstChoiceSpaceComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    firstChoiceSpaceClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "firstChoiceSpace"-------
    while continueRoutine:
        # get current time
        t = firstChoiceSpaceClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=firstChoiceSpaceClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *firstVisualStimulus* updates
        if firstVisualStimulus.status == NOT_STARTED and tThisFlip >= 0.02-frameTolerance:
            # keep track of start time/frame for later
            firstVisualStimulus.frameNStart = frameN  # exact frame index
            firstVisualStimulus.tStart = t  # local t and not account for scr refresh
            firstVisualStimulus.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(firstVisualStimulus, 'tStartRefresh')  # time at next scr refresh
            firstVisualStimulus.setAutoDraw(True)
        if firstVisualStimulus.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > firstVisualStimulus.tStartRefresh + 0.32-frameTolerance:
                # keep track of stop time/frame for later
                firstVisualStimulus.tStop = t  # not accounting for scr refresh
                firstVisualStimulus.frameNStop = frameN  # exact frame index
                win.timeOnFlip(firstVisualStimulus, 'tStopRefresh')  # time at next scr refresh
                firstVisualStimulus.setAutoDraw(False)
        # start/stop firstChoiceNoise
        if firstChoiceNoise.status == NOT_STARTED and tThisFlip >= 0.02-frameTolerance:
            # keep track of start time/frame for later
            firstChoiceNoise.frameNStart = frameN  # exact frame index
            firstChoiceNoise.tStart = t  # local t and not account for scr refresh
            firstChoiceNoise.tStartRefresh = tThisFlipGlobal  # on global time
            firstChoiceNoise.play(when=win)  # sync with win flip
        if firstChoiceNoise.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > firstChoiceNoise.tStartRefresh + 0.32-frameTolerance:
                # keep track of stop time/frame for later
                firstChoiceNoise.tStop = t  # not accounting for scr refresh
                firstChoiceNoise.frameNStop = frameN  # exact frame index
                win.timeOnFlip(firstChoiceNoise, 'tStopRefresh')  # time at next scr refresh
                firstChoiceNoise.stop()
        # start/stop firstChoiceProbeTone
        if firstChoiceProbeTone.status == NOT_STARTED and tThisFlip >= toneOnset-frameTolerance:
            # keep track of start time/frame for later
            firstChoiceProbeTone.frameNStart = frameN  # exact frame index
            firstChoiceProbeTone.tStart = t  # local t and not account for scr refresh
            firstChoiceProbeTone.tStartRefresh = tThisFlipGlobal  # on global time
            firstChoiceProbeTone.play(when=win)  # sync with win flip
        if firstChoiceProbeTone.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > firstChoiceProbeTone.tStartRefresh + toneDuration-frameTolerance:
                # keep track of stop time/frame for later
                firstChoiceProbeTone.tStop = t  # not accounting for scr refresh
                firstChoiceProbeTone.frameNStop = frameN  # exact frame index
                win.timeOnFlip(firstChoiceProbeTone, 'tStopRefresh')  # time at next scr refresh
                firstChoiceProbeTone.stop()
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in firstChoiceSpaceComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "firstChoiceSpace"-------
    for thisComponent in firstChoiceSpaceComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addOtherData('firstVisualStimulus.started', firstVisualStimulus.tStartRefresh)
    trials.addOtherData('firstVisualStimulus.stopped', firstVisualStimulus.tStopRefresh)
    firstChoiceNoise.stop()  # ensure sound has stopped at end of routine
    trials.addOtherData('firstChoiceNoise.started', firstChoiceNoise.tStartRefresh)
    trials.addOtherData('firstChoiceNoise.stopped', firstChoiceNoise.tStopRefresh)
    firstChoiceProbeTone.stop()  # ensure sound has stopped at end of routine
    trials.addOtherData('firstChoiceProbeTone.started', firstChoiceProbeTone.tStartRefresh)
    trials.addOtherData('firstChoiceProbeTone.stopped', firstChoiceProbeTone.tStopRefresh)
    # the Routine "firstChoiceSpace" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "ISI"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    # keep track of which components have finished
    ISIComponents = [ISIVisualStimulus]
    for thisComponent in ISIComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    ISIClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "ISI"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = ISIClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=ISIClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *ISIVisualStimulus* updates
        if ISIVisualStimulus.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            ISIVisualStimulus.frameNStart = frameN  # exact frame index
            ISIVisualStimulus.tStart = t  # local t and not account for scr refresh
            ISIVisualStimulus.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(ISIVisualStimulus, 'tStartRefresh')  # time at next scr refresh
            ISIVisualStimulus.setAutoDraw(True)
        if ISIVisualStimulus.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > ISIVisualStimulus.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                ISIVisualStimulus.tStop = t  # not accounting for scr refresh
                ISIVisualStimulus.frameNStop = frameN  # exact frame index
                win.timeOnFlip(ISIVisualStimulus, 'tStopRefresh')  # time at next scr refresh
                ISIVisualStimulus.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in ISIComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "ISI"-------
    for thisComponent in ISIComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addOtherData('ISIVisualStimulus.started', ISIVisualStimulus.tStartRefresh)
    trials.addOtherData('ISIVisualStimulus.stopped', ISIVisualStimulus.tStopRefresh)
    
    # ------Prepare to start Routine "secondChoiceSpace"-------
    continueRoutine = True
    # update component parameters for each repeat
    if condition == '1':
        toneDuration = 0 
    
    elif condition == '2':
        toneDuration = presetToneDuration
    
    secondChoiceNoise.setSound('Noise_BP_600_1400.wav', secs=0.32, hamming=True)
    secondChoiceNoise.setVolume(noiseVolume, log=False)
    secondChoiceTone.setSound('1000', secs=toneDuration, hamming=True)
    secondChoiceTone.setVolume(toneVolume, log=False)
    # keep track of which components have finished
    secondChoiceSpaceComponents = [secondVisualStimulus, secondChoiceNoise, secondChoiceTone]
    for thisComponent in secondChoiceSpaceComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    secondChoiceSpaceClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "secondChoiceSpace"-------
    while continueRoutine:
        # get current time
        t = secondChoiceSpaceClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=secondChoiceSpaceClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *secondVisualStimulus* updates
        if secondVisualStimulus.status == NOT_STARTED and tThisFlip >= 0.02-frameTolerance:
            # keep track of start time/frame for later
            secondVisualStimulus.frameNStart = frameN  # exact frame index
            secondVisualStimulus.tStart = t  # local t and not account for scr refresh
            secondVisualStimulus.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(secondVisualStimulus, 'tStartRefresh')  # time at next scr refresh
            secondVisualStimulus.setAutoDraw(True)
        if secondVisualStimulus.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > secondVisualStimulus.tStartRefresh + 0.32-frameTolerance:
                # keep track of stop time/frame for later
                secondVisualStimulus.tStop = t  # not accounting for scr refresh
                secondVisualStimulus.frameNStop = frameN  # exact frame index
                win.timeOnFlip(secondVisualStimulus, 'tStopRefresh')  # time at next scr refresh
                secondVisualStimulus.setAutoDraw(False)
        # start/stop secondChoiceNoise
        if secondChoiceNoise.status == NOT_STARTED and tThisFlip >= 0.02-frameTolerance:
            # keep track of start time/frame for later
            secondChoiceNoise.frameNStart = frameN  # exact frame index
            secondChoiceNoise.tStart = t  # local t and not account for scr refresh
            secondChoiceNoise.tStartRefresh = tThisFlipGlobal  # on global time
            secondChoiceNoise.play(when=win)  # sync with win flip
        if secondChoiceNoise.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > secondChoiceNoise.tStartRefresh + 0.32-frameTolerance:
                # keep track of stop time/frame for later
                secondChoiceNoise.tStop = t  # not accounting for scr refresh
                secondChoiceNoise.frameNStop = frameN  # exact frame index
                win.timeOnFlip(secondChoiceNoise, 'tStopRefresh')  # time at next scr refresh
                secondChoiceNoise.stop()
        # start/stop secondChoiceTone
        if secondChoiceTone.status == NOT_STARTED and tThisFlip >= toneOnset-frameTolerance:
            # keep track of start time/frame for later
            secondChoiceTone.frameNStart = frameN  # exact frame index
            secondChoiceTone.tStart = t  # local t and not account for scr refresh
            secondChoiceTone.tStartRefresh = tThisFlipGlobal  # on global time
            secondChoiceTone.play(when=win)  # sync with win flip
        if secondChoiceTone.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > secondChoiceTone.tStartRefresh + toneDuration-frameTolerance:
                # keep track of stop time/frame for later
                secondChoiceTone.tStop = t  # not accounting for scr refresh
                secondChoiceTone.frameNStop = frameN  # exact frame index
                win.timeOnFlip(secondChoiceTone, 'tStopRefresh')  # time at next scr refresh
                secondChoiceTone.stop()
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in secondChoiceSpaceComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "secondChoiceSpace"-------
    for thisComponent in secondChoiceSpaceComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addOtherData('secondVisualStimulus.started', secondVisualStimulus.tStartRefresh)
    trials.addOtherData('secondVisualStimulus.stopped', secondVisualStimulus.tStopRefresh)
    secondChoiceNoise.stop()  # ensure sound has stopped at end of routine
    trials.addOtherData('secondChoiceNoise.started', secondChoiceNoise.tStartRefresh)
    trials.addOtherData('secondChoiceNoise.stopped', secondChoiceNoise.tStopRefresh)
    secondChoiceTone.stop()  # ensure sound has stopped at end of routine
    trials.addOtherData('secondChoiceTone.started', secondChoiceTone.tStartRefresh)
    trials.addOtherData('secondChoiceTone.stopped', secondChoiceTone.tStopRefresh)
    # the Routine "secondChoiceSpace" was not non-slip safe, so reset the non-slip timer
    routineTimer.reset()
    
    # ------Prepare to start Routine "decisionSpace"-------
    continueRoutine = True
    routineTimer.add(10.000000)
    # update component parameters for each repeat
    corrAns = condition
    decisionKey.keys = []
    decisionKey.rt = []
    _decisionKey_allKeys = []
    # keep track of which components have finished
    decisionSpaceComponents = [decisionTextProbe, decisionKey]
    for thisComponent in decisionSpaceComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    decisionSpaceClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "decisionSpace"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = decisionSpaceClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=decisionSpaceClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *decisionTextProbe* updates
        if decisionTextProbe.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            decisionTextProbe.frameNStart = frameN  # exact frame index
            decisionTextProbe.tStart = t  # local t and not account for scr refresh
            decisionTextProbe.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(decisionTextProbe, 'tStartRefresh')  # time at next scr refresh
            decisionTextProbe.setAutoDraw(True)
        if decisionTextProbe.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > decisionTextProbe.tStartRefresh + 10-frameTolerance:
                # keep track of stop time/frame for later
                decisionTextProbe.tStop = t  # not accounting for scr refresh
                decisionTextProbe.frameNStop = frameN  # exact frame index
                win.timeOnFlip(decisionTextProbe, 'tStopRefresh')  # time at next scr refresh
                decisionTextProbe.setAutoDraw(False)
        
        # *decisionKey* updates
        waitOnFlip = False
        if decisionKey.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            decisionKey.frameNStart = frameN  # exact frame index
            decisionKey.tStart = t  # local t and not account for scr refresh
            decisionKey.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(decisionKey, 'tStartRefresh')  # time at next scr refresh
            decisionKey.status = STARTED
            # keyboard checking is just starting
            waitOnFlip = True
            win.callOnFlip(decisionKey.clock.reset)  # t=0 on next screen flip
            win.callOnFlip(decisionKey.clearEvents, eventType='keyboard')  # clear events on next screen flip
        if decisionKey.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > decisionKey.tStartRefresh + 10-frameTolerance:
                # keep track of stop time/frame for later
                decisionKey.tStop = t  # not accounting for scr refresh
                decisionKey.frameNStop = frameN  # exact frame index
                win.timeOnFlip(decisionKey, 'tStopRefresh')  # time at next scr refresh
                decisionKey.status = FINISHED
        if decisionKey.status == STARTED and not waitOnFlip:
            theseKeys = decisionKey.getKeys(keyList=['1', '2'], waitRelease=False)
            _decisionKey_allKeys.extend(theseKeys)
            if len(_decisionKey_allKeys):
                decisionKey.keys = _decisionKey_allKeys[-1].name  # just the last key pressed
                decisionKey.rt = _decisionKey_allKeys[-1].rt
                # was this correct?
                if (decisionKey.keys == str(corrAns)) or (decisionKey.keys == corrAns):
                    decisionKey.corr = 1
                else:
                    decisionKey.corr = 0
                # a response ends the routine
                continueRoutine = False
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in decisionSpaceComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "decisionSpace"-------
    for thisComponent in decisionSpaceComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    trials.addOtherData('decisionTextProbe.started', decisionTextProbe.tStartRefresh)
    trials.addOtherData('decisionTextProbe.stopped', decisionTextProbe.tStopRefresh)
    # check responses
    if decisionKey.keys in ['', [], None]:  # No response was made
        decisionKey.keys = None
        # was no response the correct answer?!
        if str(corrAns).lower() == 'none':
           decisionKey.corr = 1;  # correct non-response
        else:
           decisionKey.corr = 0;  # failed to respond (incorrectly)
    # store data for trials (MultiStairHandler)
    trials.addResponse(decisionKey.corr)
    trials.addOtherData('decisionKey.rt', decisionKey.rt)
    trials.addOtherData('decisionKey.started', decisionKey.tStartRefresh)
    trials.addOtherData('decisionKey.stopped', decisionKey.tStopRefresh)
    
    # ------Prepare to start Routine "feedbackSpace"-------
    continueRoutine = True
    routineTimer.add(1.000000)
    # update component parameters for each repeat
    if decisionKey.keys[0] == str(corrAns):
       feedback = "Correct" 
    
    if decisionKey.keys[0] != str(corrAns):
       feedback = "Incorrect" 
    
    
    feedbackText.setText(feedback)
    # keep track of which components have finished
    feedbackSpaceComponents = [feedbackText]
    for thisComponent in feedbackSpaceComponents:
        thisComponent.tStart = None
        thisComponent.tStop = None
        thisComponent.tStartRefresh = None
        thisComponent.tStopRefresh = None
        if hasattr(thisComponent, 'status'):
            thisComponent.status = NOT_STARTED
    # reset timers
    t = 0
    _timeToFirstFrame = win.getFutureFlipTime(clock="now")
    feedbackSpaceClock.reset(-_timeToFirstFrame)  # t0 is time of first possible flip
    frameN = -1
    
    # -------Run Routine "feedbackSpace"-------
    while continueRoutine and routineTimer.getTime() > 0:
        # get current time
        t = feedbackSpaceClock.getTime()
        tThisFlip = win.getFutureFlipTime(clock=feedbackSpaceClock)
        tThisFlipGlobal = win.getFutureFlipTime(clock=None)
        frameN = frameN + 1  # number of completed frames (so 0 is the first frame)
        # update/draw components on each frame
        
        # *feedbackText* updates
        if feedbackText.status == NOT_STARTED and tThisFlip >= 0.0-frameTolerance:
            # keep track of start time/frame for later
            feedbackText.frameNStart = frameN  # exact frame index
            feedbackText.tStart = t  # local t and not account for scr refresh
            feedbackText.tStartRefresh = tThisFlipGlobal  # on global time
            win.timeOnFlip(feedbackText, 'tStartRefresh')  # time at next scr refresh
            feedbackText.setAutoDraw(True)
        if feedbackText.status == STARTED:
            # is it time to stop? (based on global clock, using actual start)
            if tThisFlipGlobal > feedbackText.tStartRefresh + 1.0-frameTolerance:
                # keep track of stop time/frame for later
                feedbackText.tStop = t  # not accounting for scr refresh
                feedbackText.frameNStop = frameN  # exact frame index
                win.timeOnFlip(feedbackText, 'tStopRefresh')  # time at next scr refresh
                feedbackText.setAutoDraw(False)
        
        # check for quit (typically the Esc key)
        if endExpNow or defaultKeyboard.getKeys(keyList=["escape"]):
            core.quit()
        
        # check if all components have finished
        if not continueRoutine:  # a component has requested a forced-end of Routine
            break
        continueRoutine = False  # will revert to True if at least one component still running
        for thisComponent in feedbackSpaceComponents:
            if hasattr(thisComponent, "status") and thisComponent.status != FINISHED:
                continueRoutine = True
                break  # at least one component has not yet finished
        
        # refresh the screen
        if continueRoutine:  # don't flip if this routine is over or we'll get a blank screen
            win.flip()
    
    # -------Ending Routine "feedbackSpace"-------
    for thisComponent in feedbackSpaceComponents:
        if hasattr(thisComponent, "setAutoDraw"):
            thisComponent.setAutoDraw(False)
    print('trialNumber:', trialNumber, 'tone was presented in interval: ', condition, 'toneVolume was:', toneVolume, 'participant was: ', feedback)
    trialNumber = trialNumber + 1
    trials.addOtherData('feedbackText.started', feedbackText.tStartRefresh)
    trials.addOtherData('feedbackText.stopped', feedbackText.tStopRefresh)
    thisExp.nextEntry()
    
# all staircases completed


# Flip one final time so any remaining win.callOnFlip() 
# and win.timeOnFlip() tasks get executed before quitting
win.flip()

# these shouldn't be strictly necessary (should auto-save)
thisExp.saveAsWideText(filename+'.csv')
thisExp.saveAsPickle(filename)
logging.flush()
# make sure everything is closed down
thisExp.abort()  # or data files will save again on exit
win.close()
core.quit()
