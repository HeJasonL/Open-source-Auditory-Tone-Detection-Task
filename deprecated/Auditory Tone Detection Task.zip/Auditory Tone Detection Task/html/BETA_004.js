﻿/***************** 
 * Beta_004 Test *
 *****************/

import { PsychoJS } from 'https://pavlovia.org/lib/core.js';
import * as core from 'https://pavlovia.org/lib/core.js';
import { TrialHandler } from 'https://pavlovia.org/lib/data.js';
import { Scheduler } from 'https://pavlovia.org/lib/util.js';
import * as util from 'https://pavlovia.org/lib/util.js';
import * as visual from 'https://pavlovia.org/lib/visual.js';
import { Sound } from 'https://pavlovia.org/lib/sound.js';

// init psychoJS:
var psychoJS = new PsychoJS({
  debug: true
});

// open window:
psychoJS.openWindow({
  fullscr: true,
  color: new util.Color([0, 0, 0]),
  units: 'height'
});

// store info about the experiment session:
let expName = 'BETA_004';  // from the Builder filename that created this script
let expInfo = {'participant': '', 'session': '001'};

// schedule the experiment:
psychoJS.schedule(psychoJS.gui.DlgFromDict({
  dictionary: expInfo,
  title: expName
}));

const flowScheduler = new Scheduler(psychoJS);
const dialogCancelScheduler = new Scheduler(psychoJS);
psychoJS.scheduleCondition(function() { return (psychoJS.gui.dialogComponent.button === 'OK'); }, flowScheduler, dialogCancelScheduler);

// flowScheduler gets run if the participants presses OK
flowScheduler.add(updateInfo); // add timeStamp
flowScheduler.add(experimentInit);
flowScheduler.add(WelcomeRoutineBegin);
flowScheduler.add(WelcomeRoutineEachFrame);
flowScheduler.add(WelcomeRoutineEnd);
flowScheduler.add(InstructionsRoutineBegin);
flowScheduler.add(InstructionsRoutineEachFrame);
flowScheduler.add(InstructionsRoutineEnd);
const trialsLoopScheduler = new Scheduler(psychoJS);
flowScheduler.add(trialsLoopBegin, trialsLoopScheduler);
flowScheduler.add(trialsLoopScheduler);
flowScheduler.add(trialsLoopEnd);
flowScheduler.add(quitPsychoJS, '', true);

// quit if user presses Cancel in dialog box:
dialogCancelScheduler.add(quitPsychoJS, '', false);

psychoJS.start({expName, expInfo});

var frameDur;
function updateInfo() {
  expInfo['date'] = util.MonotonicClock.getDateStr();  // add a simple timestamp
  expInfo['expName'] = expName;
  expInfo['psychopyVersion'] = '3.1.2';

  // store frame rate of monitor if we can measure it successfully
  expInfo['frameRate'] = psychoJS.window.getActualFrameRate();
  if (typeof expInfo['frameRate'] !== 'undefined')
    frameDur = 1.0/Math.round(expInfo['frameRate']);
  else
    frameDur = 1.0/60.0; // couldn't get a reliable measure so guess

  // add info from the URL:
  util.addInfoFromUrl(expInfo);
  
  return Scheduler.Event.NEXT;
}

var WelcomeClock;
var Welcome_Text;
var InstructionsClock;
var instructionsText;
var TrialClock;
var probeTone1;
var delay;
var ISI;
var probeTone2;
var bandpassNoise1;
var bandpassNoise2;
var interval1;
var interval2;
var QuestionClock;
var questionText;
var FeedbackClock;
var feedbackText;
var globalClock;
var routineTimer;
function experimentInit() {
  // Initialize components for Routine "Welcome"
  WelcomeClock = new util.Clock();
  Welcome_Text = new visual.TextStim({
    win: psychoJS.window,
    name: 'Welcome_Text',
    text: 'Welcome to the Auditory Tone Detection Task\n\nPress SPACE to continue',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  // Initialize components for Routine "Instructions"
  InstructionsClock = new util.Clock();
  instructionsText = new visual.TextStim({
    win: psychoJS.window,
    name: 'instructionsText',
    text: 'In this task, you will be presented with trials.\nIn each of these trials, you will be presented with two listening intervals.\nA tone will be presented in only one of the two intervals. \n\nThe listening intervals will be visually indicated by the numbers "1" and "2", separated by a short delay.\nAfter the two listening intervals, you must decide in which interval you heard the tone.\n\nPress SPACE for to begin',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.03,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  // Initialize components for Routine "Trial"
  TrialClock = new util.Clock();
  probeTone1 = new Sound({
    win: psychoJS.window,
    value: '1000',
    secs: (- 1),
    });
  probeTone1.setVolume(1.0);
  delay = new visual.TextStim({
    win: psychoJS.window,
    name: 'delay',
    text: '\n+\n',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('black'),  opacity: 1,
    depth: -2.0 
  });
  
  ISI = new visual.TextStim({
    win: psychoJS.window,
    name: 'ISI',
    text: '',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('black'),  opacity: 1,
    depth: -3.0 
  });
  
  probeTone2 = new Sound({
    win: psychoJS.window,
    value: '1000',
    secs: (- 1),
    });
  probeTone2.setVolume(1.0);
  bandpassNoise1 = new Sound({
    win: psychoJS.window,
    value: 'Noise_BP_600_1400.wav',
    secs: 0.3,
    });
  bandpassNoise1.setVolume(1);
  bandpassNoise2 = new Sound({
    win: psychoJS.window,
    value: 'Noise_BP_600_1400.wav',
    secs: 0.3,
    });
  bandpassNoise2.setVolume(1);
  interval1 = new visual.TextStim({
    win: psychoJS.window,
    name: 'interval1',
    text: '1',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.75,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -7.0 
  });
  
  interval2 = new visual.TextStim({
    win: psychoJS.window,
    name: 'interval2',
    text: '2',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.75,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -8.0 
  });
  
  // Initialize components for Routine "Question"
  QuestionClock = new util.Clock();
  questionText = new visual.TextStim({
    win: psychoJS.window,
    name: 'questionText',
    text: 'In which interval ("1" or "2") do you think you heard the tone? \n\nRespond using the number pad. If you are unsure, just pick the interval you are most confident with.',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.05,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: 0.0 
  });
  
  // Initialize components for Routine "Feedback"
  FeedbackClock = new util.Clock();
  feedbackText = new visual.TextStim({
    win: psychoJS.window,
    name: 'feedbackText',
    text: 'default text',
    font: 'Arial',
    units : undefined, 
    pos: [0, 0], height: 0.1,  wrapWidth: undefined, ori: 0,
    color: new util.Color('white'),  opacity: 1,
    depth: -1.0 
  });
  
  // Create some handy timers
  globalClock = new util.Clock();  // to track the time since experiment started
  routineTimer = new util.CountdownTimer();  // to track time remaining of each (non-slip) routine
  
  return Scheduler.Event.NEXT;
}

var t;
var frameN;
var Welcome_Response;
var WelcomeComponents;
function WelcomeRoutineBegin() {
  //------Prepare to start Routine 'Welcome'-------
  t = 0;
  WelcomeClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  Welcome_Response = new core.BuilderKeyResponse(psychoJS);
  
  // keep track of which components have finished
  WelcomeComponents = [];
  WelcomeComponents.push(Welcome_Text);
  WelcomeComponents.push(Welcome_Response);
  
  for (const thisComponent of WelcomeComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}

var continueRoutine;
function WelcomeRoutineEachFrame() {
  //------Loop for each frame of Routine 'Welcome'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = WelcomeClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *Welcome_Text* updates
  if (t >= 0.0 && Welcome_Text.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Welcome_Text.tStart = t;  // (not accounting for frame time here)
    Welcome_Text.frameNStart = frameN;  // exact frame index
    Welcome_Text.setAutoDraw(true);
  }

  
  // *Welcome_Response* updates
  if (t >= 0.0 && Welcome_Response.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    Welcome_Response.tStart = t;  // (not accounting for frame time here)
    Welcome_Response.frameNStart = frameN;  // exact frame index
    Welcome_Response.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { Welcome_Response.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (Welcome_Response.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      Welcome_Response.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      Welcome_Response.rt = Welcome_Response.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of WelcomeComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function WelcomeRoutineEnd() {
  //------Ending Routine 'Welcome'-------
  for (const thisComponent of WelcomeComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  // check responses
  if (Welcome_Response.keys === undefined || Welcome_Response.keys.length === 0) {    // No response was made
      Welcome_Response.keys = undefined;
  }
  
  psychoJS.experiment.addData('Welcome_Response.keys', Welcome_Response.keys);
  if (typeof Welcome_Response.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('Welcome_Response.rt', Welcome_Response.rt);
      routineTimer.reset();
      }
  
  // the Routine "Welcome" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var instructionsResponse;
var InstructionsComponents;
function InstructionsRoutineBegin() {
  //------Prepare to start Routine 'Instructions'-------
  t = 0;
  InstructionsClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  instructionsResponse = new core.BuilderKeyResponse(psychoJS);
  
  // keep track of which components have finished
  InstructionsComponents = [];
  InstructionsComponents.push(instructionsText);
  InstructionsComponents.push(instructionsResponse);
  
  for (const thisComponent of InstructionsComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function InstructionsRoutineEachFrame() {
  //------Loop for each frame of Routine 'Instructions'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = InstructionsClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *instructionsText* updates
  if (t >= 0.0 && instructionsText.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    instructionsText.tStart = t;  // (not accounting for frame time here)
    instructionsText.frameNStart = frameN;  // exact frame index
    instructionsText.setAutoDraw(true);
  }

  
  // *instructionsResponse* updates
  if (t >= 0.0 && instructionsResponse.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    instructionsResponse.tStart = t;  // (not accounting for frame time here)
    instructionsResponse.frameNStart = frameN;  // exact frame index
    instructionsResponse.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { instructionsResponse.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (instructionsResponse.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['space']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      instructionsResponse.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      instructionsResponse.rt = instructionsResponse.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of InstructionsComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function InstructionsRoutineEnd() {
  //------Ending Routine 'Instructions'-------
  for (const thisComponent of InstructionsComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  // check responses
  if (instructionsResponse.keys === undefined || instructionsResponse.keys.length === 0) {    // No response was made
      instructionsResponse.keys = undefined;
  }
  
  psychoJS.experiment.addData('instructionsResponse.keys', instructionsResponse.keys);
  if (typeof instructionsResponse.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('instructionsResponse.rt', instructionsResponse.rt);
      routineTimer.reset();
      }
  
  // the Routine "Instructions" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var trials;
var currentLoop;
function trialsLoopBegin(thisScheduler) {
  // set up handler to look after randomisation of conditions etc
  trials = new TrialHandler({
    psychoJS: psychoJS,
    nReps: 4, method: TrialHandler.Method.RANDOM,
    extraInfo: expInfo, originPath: undefined,
    trialList: 'conditions.xlsx',
    seed: undefined, name: 'trials'});
  psychoJS.experiment.addLoop(trials); // add the loop to the experiment
  currentLoop = trials;  // we're now the current loop

  // Schedule all the trials in the trialList:
  for (const thisTrial of trials) {
    thisScheduler.add(importConditions(trials));
    thisScheduler.add(TrialRoutineBegin);
    thisScheduler.add(TrialRoutineEachFrame);
    thisScheduler.add(TrialRoutineEnd);
    thisScheduler.add(QuestionRoutineBegin);
    thisScheduler.add(QuestionRoutineEachFrame);
    thisScheduler.add(QuestionRoutineEnd);
    thisScheduler.add(FeedbackRoutineBegin);
    thisScheduler.add(FeedbackRoutineEachFrame);
    thisScheduler.add(FeedbackRoutineEnd);
    thisScheduler.add(endLoopIteration(thisScheduler, thisTrial));
  }

  return Scheduler.Event.NEXT;
}


function trialsLoopEnd() {
  psychoJS.experiment.removeLoop(trials);

  return Scheduler.Event.NEXT;
}

var TrialComponents;
function TrialRoutineBegin() {
  //------Prepare to start Routine 'Trial'-------
  t = 0;
  TrialClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  probeTone1.secs=probe1Duration;
  probeTone1.setVolume(toneVolume);
  probeTone2.secs=probe2Duration;
  probeTone2.setVolume(toneVolume);
  bandpassNoise1.secs=0.3;
  bandpassNoise1.setVolume(1);
  bandpassNoise2.secs=0.3;
  bandpassNoise2.setVolume(1);
  // keep track of which components have finished
  TrialComponents = [];
  TrialComponents.push(probeTone1);
  TrialComponents.push(delay);
  TrialComponents.push(ISI);
  TrialComponents.push(probeTone2);
  TrialComponents.push(bandpassNoise1);
  TrialComponents.push(bandpassNoise2);
  TrialComponents.push(interval1);
  TrialComponents.push(interval2);
  
  for (const thisComponent of TrialComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}

var frameRemains;
function TrialRoutineEachFrame() {
  //------Loop for each frame of Routine 'Trial'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = TrialClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  // start/stop probeTone1
  if (t >= probe1Onset && probeTone1.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    probeTone1.tStart = t;  // (not accounting for frame time here)
    probeTone1.frameNStart = frameN;  // exact frame index
    psychoJS.window.callOnFlip(function(){ probeTone1.play(); });  // screen flip
    probeTone1.status = PsychoJS.Status.STARTED;
  }
  frameRemains = probe1Onset + probe1Duration - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (probeTone1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    if (probe1Duration > 0.5) {  probeTone1.stop();  // stop the sound (if longer than duration)
      probeTone1.status = PsychoJS.Status.FINISHED;
    }
  }
  
  // *delay* updates
  if (t >= 0.0 && delay.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    delay.tStart = t;  // (not accounting for frame time here)
    delay.frameNStart = frameN;  // exact frame index
    delay.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (delay.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    delay.setAutoDraw(false);
  }
  
  // *ISI* updates
  if (t >= 1.3 && ISI.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    ISI.tStart = t;  // (not accounting for frame time here)
    ISI.frameNStart = frameN;  // exact frame index
    ISI.setAutoDraw(true);
  }

  frameRemains = 1.3 + 0.8 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (ISI.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    ISI.setAutoDraw(false);
  }
  // start/stop probeTone2
  if (t >= probe2Onset && probeTone2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    probeTone2.tStart = t;  // (not accounting for frame time here)
    probeTone2.frameNStart = frameN;  // exact frame index
    psychoJS.window.callOnFlip(function(){ probeTone2.play(); });  // screen flip
    probeTone2.status = PsychoJS.Status.STARTED;
  }
  frameRemains = probe2Onset + probe2Duration - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (probeTone2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    if (probe2Duration > 0.5) {  probeTone2.stop();  // stop the sound (if longer than duration)
      probeTone2.status = PsychoJS.Status.FINISHED;
    }
  }
  // start/stop bandpassNoise1
  if (t >= 1 && bandpassNoise1.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    bandpassNoise1.tStart = t;  // (not accounting for frame time here)
    bandpassNoise1.frameNStart = frameN;  // exact frame index
    psychoJS.window.callOnFlip(function(){ bandpassNoise1.play(); });  // screen flip
    bandpassNoise1.status = PsychoJS.Status.STARTED;
  }
  frameRemains = 1 + 0.3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (bandpassNoise1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    if (0.3 > 0.5) {  bandpassNoise1.stop();  // stop the sound (if longer than duration)
      bandpassNoise1.status = PsychoJS.Status.FINISHED;
    }
  }
  // start/stop bandpassNoise2
  if (t >= 2.1 && bandpassNoise2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    bandpassNoise2.tStart = t;  // (not accounting for frame time here)
    bandpassNoise2.frameNStart = frameN;  // exact frame index
    psychoJS.window.callOnFlip(function(){ bandpassNoise2.play(); });  // screen flip
    bandpassNoise2.status = PsychoJS.Status.STARTED;
  }
  frameRemains = 2.1 + 0.3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (bandpassNoise2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    if (0.3 > 0.5) {  bandpassNoise2.stop();  // stop the sound (if longer than duration)
      bandpassNoise2.status = PsychoJS.Status.FINISHED;
    }
  }
  
  // *interval1* updates
  if (t >= 1 && interval1.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    interval1.tStart = t;  // (not accounting for frame time here)
    interval1.frameNStart = frameN;  // exact frame index
    interval1.setAutoDraw(true);
  }

  frameRemains = 1 + 0.3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (interval1.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    interval1.setAutoDraw(false);
  }
  
  // *interval2* updates
  if (t >= 2.1 && interval2.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    interval2.tStart = t;  // (not accounting for frame time here)
    interval2.frameNStart = frameN;  // exact frame index
    interval2.setAutoDraw(true);
  }

  frameRemains = 2.1 + 0.3 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (interval2.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    interval2.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of TrialComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function TrialRoutineEnd() {
  //------Ending Routine 'Trial'-------
  for (const thisComponent of TrialComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  probeTone1.stop();  // ensure sound has stopped at end of routine
  probeTone2.stop();  // ensure sound has stopped at end of routine
  bandpassNoise1.stop();  // ensure sound has stopped at end of routine
  bandpassNoise2.stop();  // ensure sound has stopped at end of routine
  // the Routine "Trial" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var questionResponse;
var QuestionComponents;
function QuestionRoutineBegin() {
  //------Prepare to start Routine 'Question'-------
  t = 0;
  QuestionClock.reset(); // clock
  frameN = -1;
  // update component parameters for each repeat
  questionResponse = new core.BuilderKeyResponse(psychoJS);
  
  // keep track of which components have finished
  QuestionComponents = [];
  QuestionComponents.push(questionText);
  QuestionComponents.push(questionResponse);
  
  for (const thisComponent of QuestionComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function QuestionRoutineEachFrame() {
  //------Loop for each frame of Routine 'Question'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = QuestionClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *questionText* updates
  if (t >= 0.0 && questionText.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    questionText.tStart = t;  // (not accounting for frame time here)
    questionText.frameNStart = frameN;  // exact frame index
    questionText.setAutoDraw(true);
  }

  
  // *questionResponse* updates
  if (t >= 0.0 && questionResponse.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    questionResponse.tStart = t;  // (not accounting for frame time here)
    questionResponse.frameNStart = frameN;  // exact frame index
    questionResponse.status = PsychoJS.Status.STARTED;
    // keyboard checking is just starting
    psychoJS.window.callOnFlip(function() { questionResponse.clock.reset(); }); // t = 0 on screen flip
    psychoJS.eventManager.clearEvents({eventType:'keyboard'});
  }

  if (questionResponse.status === PsychoJS.Status.STARTED) {
    let theseKeys = psychoJS.eventManager.getKeys({keyList:['1', '2']});
    
    // check for quit:
    if (theseKeys.indexOf('escape') > -1) {
      psychoJS.experiment.experimentEnded = true;
    }
    
    if (theseKeys.length > 0) {  // at least one key was pressed
      questionResponse.keys = theseKeys[theseKeys.length-1];  // just the last key pressed
      questionResponse.rt = questionResponse.clock.getTime();
      // a response ends the routine
      continueRoutine = false;
    }
  }
  
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of QuestionComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function QuestionRoutineEnd() {
  //------Ending Routine 'Question'-------
  for (const thisComponent of QuestionComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  
  // check responses
  if (questionResponse.keys === undefined || questionResponse.keys.length === 0) {    // No response was made
      questionResponse.keys = undefined;
  }
  
  psychoJS.experiment.addData('questionResponse.keys', questionResponse.keys);
  if (typeof questionResponse.keys !== 'undefined') {  // we had a response
      psychoJS.experiment.addData('questionResponse.rt', questionResponse.rt);
      routineTimer.reset();
      }
  
  // the Routine "Question" was not non-slip safe, so reset the non-slip timer
  routineTimer.reset();
  
  return Scheduler.Event.NEXT;
}

var FeedbackComponents;
function FeedbackRoutineBegin() {
  //------Prepare to start Routine 'Feedback'-------
  t = 0;
  FeedbackClock.reset(); // clock
  frameN = -1;
  routineTimer.add(1.000000);
  // update component parameters for each repeat
  feedbackText.setColor(new util.Color('white'));
  feedbackText.setText(toneVolume);
  // keep track of which components have finished
  FeedbackComponents = [];
  FeedbackComponents.push(feedbackText);
  
  for (const thisComponent of FeedbackComponents)
    if ('status' in thisComponent)
      thisComponent.status = PsychoJS.Status.NOT_STARTED;
  
  return Scheduler.Event.NEXT;
}


function FeedbackRoutineEachFrame() {
  //------Loop for each frame of Routine 'Feedback'-------
  let continueRoutine = true; // until we're told otherwise
  // get current time
  t = FeedbackClock.getTime();
  frameN = frameN + 1;// number of completed frames (so 0 is the first frame)
  // update/draw components on each frame
  
  // *feedbackText* updates
  if (t >= 0.0 && feedbackText.status === PsychoJS.Status.NOT_STARTED) {
    // keep track of start time/frame for later
    feedbackText.tStart = t;  // (not accounting for frame time here)
    feedbackText.frameNStart = frameN;  // exact frame index
    feedbackText.setAutoDraw(true);
  }

  frameRemains = 0.0 + 1.0 - psychoJS.window.monitorFramePeriod * 0.75;  // most of one frame period left
  if (feedbackText.status === PsychoJS.Status.STARTED && t >= frameRemains) {
    feedbackText.setAutoDraw(false);
  }
  // check for quit (typically the Esc key)
  if (psychoJS.experiment.experimentEnded || psychoJS.eventManager.getKeys({keyList:['escape']}).length > 0) {
    return psychoJS.quit('The [Escape] key was pressed. Goodbye!', false);
  }
  
  // check if the Routine should terminate
  if (!continueRoutine) {  // a component has requested a forced-end of Routine
    return Scheduler.Event.NEXT;
  }
  
  continueRoutine = false;  // reverts to True if at least one component still running
  for (const thisComponent of FeedbackComponents)
    if ('status' in thisComponent && thisComponent.status !== PsychoJS.Status.FINISHED) {
      continueRoutine = true;
      break;
    }
  
  // refresh the screen if continuing
  if (continueRoutine && routineTimer.getTime() > 0) {
    return Scheduler.Event.FLIP_REPEAT;
  }
  else {
    return Scheduler.Event.NEXT;
  }
}


function FeedbackRoutineEnd() {
  //------Ending Routine 'Feedback'-------
  for (const thisComponent of FeedbackComponents) {
    if (typeof thisComponent.setAutoDraw === 'function') {
      thisComponent.setAutoDraw(false);
    }
  }
  return Scheduler.Event.NEXT;
}


function endLoopIteration(thisScheduler, thisTrial) {
  // ------Prepare for next entry------
  return function () {
    // ------Check if user ended loop early------
    if (currentLoop.finished) {
      thisScheduler.stop();
    } else if (typeof thisTrial === 'undefined' || !('isTrials' in thisTrial) || thisTrial.isTrials) {
      psychoJS.experiment.nextEntry();
    }
  return Scheduler.Event.NEXT;
  };
}


function importConditions(loop) {
  const trialIndex = loop.getTrialIndex();
  return function () {
    loop.setTrialIndex(trialIndex);
    psychoJS.importAttributes(loop.getCurrentTrial());
    return Scheduler.Event.NEXT;
    };
}


function quitPsychoJS(message, isCompleted) {
  psychoJS.window.close();
  psychoJS.quit({message: message, isCompleted: isCompleted});

  return Scheduler.Event.QUIT;
}
